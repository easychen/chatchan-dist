self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fd32cfb2b5d08bfb813b",
    "url": "./d032240921e3b8f45d06.module.wasm"
  },
  {
    "revision": "5e0d96ab853aa3e54a9bff93e47e6230",
    "url": "./index.html"
  },
  {
    "revision": "62e936dbc63c4283686c",
    "url": "./static/css/2.c412fb8a.chunk.css"
  },
  {
    "revision": "56d3f7427b0187a6bc7e",
    "url": "./static/css/main.34bf5f7b.chunk.css"
  },
  {
    "revision": "62e936dbc63c4283686c",
    "url": "./static/js/2.e243588d.chunk.js"
  },
  {
    "revision": "fd32cfb2b5d08bfb813b",
    "url": "./static/js/3.bc5a8cfa.chunk.js"
  },
  {
    "revision": "56d3f7427b0187a6bc7e",
    "url": "./static/js/main.b7086df4.chunk.js"
  },
  {
    "revision": "a53c3657d5b2dc6048af",
    "url": "./static/js/runtime-main.8406c0a2.js"
  },
  {
    "revision": "05f1cdadfe476395f60e233b15c22155",
    "url": "./static/media/icons-16.05f1cdad.eot"
  },
  {
    "revision": "3c1c220e7a18286503fb431c7a7fe183",
    "url": "./static/media/icons-16.3c1c220e.woff"
  },
  {
    "revision": "3cde8748332d1de6b1ae1c2dc5850754",
    "url": "./static/media/icons-16.3cde8748.ttf"
  },
  {
    "revision": "0a5c76518a68c185baa2c6744456918c",
    "url": "./static/media/icons-20.0a5c7651.eot"
  },
  {
    "revision": "51ec31f302d0072808e1f83f85fea4cd",
    "url": "./static/media/icons-20.51ec31f3.ttf"
  },
  {
    "revision": "cef8cdbb9d0ba82e6e19fb0eeba2ac3d",
    "url": "./static/media/icons-20.cef8cdbb.woff"
  }
]);