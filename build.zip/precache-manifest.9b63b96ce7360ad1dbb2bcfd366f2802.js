self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fd32cfb2b5d08bfb813b",
    "url": "./d032240921e3b8f45d06.module.wasm"
  },
  {
    "revision": "d2d726d4128d54441d89c1488aa08964",
    "url": "./index.html"
  },
  {
    "revision": "8d96b08f5ec84c281de3",
    "url": "./static/css/2.c412fb8a.chunk.css"
  },
  {
    "revision": "232f1e13a11c2868c1e5",
    "url": "./static/css/main.34bf5f7b.chunk.css"
  },
  {
    "revision": "8d96b08f5ec84c281de3",
    "url": "./static/js/2.6accb1d5.chunk.js"
  },
  {
    "revision": "fd32cfb2b5d08bfb813b",
    "url": "./static/js/3.bc5a8cfa.chunk.js"
  },
  {
    "revision": "232f1e13a11c2868c1e5",
    "url": "./static/js/main.e0aad89f.chunk.js"
  },
  {
    "revision": "a53c3657d5b2dc6048af",
    "url": "./static/js/runtime-main.8406c0a2.js"
  },
  {
    "revision": "05f1cdadfe476395f60e233b15c22155",
    "url": "./static/media/icons-16.05f1cdad.eot"
  },
  {
    "revision": "3c1c220e7a18286503fb431c7a7fe183",
    "url": "./static/media/icons-16.3c1c220e.woff"
  },
  {
    "revision": "3cde8748332d1de6b1ae1c2dc5850754",
    "url": "./static/media/icons-16.3cde8748.ttf"
  },
  {
    "revision": "0a5c76518a68c185baa2c6744456918c",
    "url": "./static/media/icons-20.0a5c7651.eot"
  },
  {
    "revision": "51ec31f302d0072808e1f83f85fea4cd",
    "url": "./static/media/icons-20.51ec31f3.ttf"
  },
  {
    "revision": "cef8cdbb9d0ba82e6e19fb0eeba2ac3d",
    "url": "./static/media/icons-20.cef8cdbb.woff"
  }
]);