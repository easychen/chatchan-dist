self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7c54a3b21ea2702667a1",
    "url": "./d032240921e3b8f45d06.module.wasm"
  },
  {
    "revision": "11751b786dfb66fcbee52f441e03f7f0",
    "url": "./index.html"
  },
  {
    "revision": "3943ac08e9ccbe9aa1f2",
    "url": "./static/css/2.c412fb8a.chunk.css"
  },
  {
    "revision": "be6ee58809b80c2cc1e0",
    "url": "./static/css/main.34bf5f7b.chunk.css"
  },
  {
    "revision": "3943ac08e9ccbe9aa1f2",
    "url": "./static/js/2.d92956b3.chunk.js"
  },
  {
    "revision": "7c54a3b21ea2702667a1",
    "url": "./static/js/3.3fcd724d.chunk.js"
  },
  {
    "revision": "be6ee58809b80c2cc1e0",
    "url": "./static/js/main.10f0346a.chunk.js"
  },
  {
    "revision": "de1eee476ce09478550d",
    "url": "./static/js/runtime-main.5676d25d.js"
  },
  {
    "revision": "05f1cdadfe476395f60e233b15c22155",
    "url": "./static/media/icons-16.05f1cdad.eot"
  },
  {
    "revision": "3c1c220e7a18286503fb431c7a7fe183",
    "url": "./static/media/icons-16.3c1c220e.woff"
  },
  {
    "revision": "3cde8748332d1de6b1ae1c2dc5850754",
    "url": "./static/media/icons-16.3cde8748.ttf"
  },
  {
    "revision": "0a5c76518a68c185baa2c6744456918c",
    "url": "./static/media/icons-20.0a5c7651.eot"
  },
  {
    "revision": "51ec31f302d0072808e1f83f85fea4cd",
    "url": "./static/media/icons-20.51ec31f3.ttf"
  },
  {
    "revision": "cef8cdbb9d0ba82e6e19fb0eeba2ac3d",
    "url": "./static/media/icons-20.cef8cdbb.woff"
  }
]);